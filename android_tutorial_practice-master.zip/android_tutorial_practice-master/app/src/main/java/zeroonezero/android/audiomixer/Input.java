package zeroonezero.android.audiomixer;

import android.net.Uri;

public class Input {
    public Uri uri;
    public long durationUs;
    public long startOffsetUs;
    public long startTimeUs;
    public long endTimeUs;
}
